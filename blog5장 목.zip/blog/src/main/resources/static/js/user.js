let index = {
	init:function(){
		$("#btn-save").on("click",()=>{
			this.save();
		});
	},
	
	save:function(){
		alert('user의 save함수 호출됨');
		//alert('user의 save함수 호출됨');
let data = {
	username: $("#username").val(),
	password: $("#password").val(),
	email: $("#email").val()
}
	
console.log(data);
console.log(JSON.stringify(data)); //JSON 문자열
	}
}

index.init();