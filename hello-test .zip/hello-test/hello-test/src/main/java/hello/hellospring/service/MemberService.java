package hello.hellospring.service;

import hello.hellospring.domain.Member;
import hello.hellospring.repository.MemberRepository;
import hello.hellospring.repository.MemoryMemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
@Transactional
public class MemberService {
    private final MemberRepository memberRepository;

    @Autowired
    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    //ȸ������
    public Long join(Member member) {
        //���� �̸��� �ִ� �ߺ�ȸ�� X
        Optional<Member> result = memberRepository.findByName((member.getName()));
        validateDuplicateMember(result);
        memberRepository.save(member);
        return member.getId();

    }

    private static void validateDuplicateMember(Optional<Member> result) {
        result.ifPresent(m -> {
            throw new IllegalStateException("�̹� �����ϴ� ȸ���Դϴ�.");
        });
    }

    //��ü ȸ�� ��ȸ

    public List<Member> findMembers(){
        return memberRepository.findAll();
    }

    //Ư�� ȸ�� ��ȸ
    public Optional<Member> findOne(Long memberId){
        return memberRepository.findById(memberId);
    }

}

