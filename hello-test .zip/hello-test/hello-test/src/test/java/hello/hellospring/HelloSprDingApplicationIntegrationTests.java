package hello.hellospring;


import hello.hellospring.domain.Member;
import hello.hellospring.repository.MemoryMemberRepository;
import hello.hellospring.service.MemberService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.fail;


public class HelloSprDingApplicationIntegrationTests {
    @Autowired
    MemberService memberService;
    @Autowired
    MemoryMemberRepository memberRepository;

/*    @Test
    public void valid_exception(){
        //given
        Member member1 = new Member();
        member1.setName("spring");

        Member member2 = new Member();
        member2.setName("spring");
        //when
        memberService.join(member1);
        try {
            memberService.join(member2);
            fail();
        }catch (IllegalStateException e){
            assertThat(e.getMessage()).isEqualTo("�̹� �����ϴ� ȸ���Դϴ�.");
        }
        //then
    }*/
    @Test
    void join(){
        //given - �غ�
        Member member = new Member();
        member.setName("spring");

        //when - ����
        Long saveId = memberService.join(member);

        //then - ����
        Member findMember = memberService.findOne(saveId).get();
        assertThat(member.getName()).isEqualTo(findMember.getName());
    }
    @Test
    void findMembers(){

    }
    @Test
    void findOne(){

    }
}
